import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class SelectInsteadOfDeleteTests(unittest.TestCase):
    def test_extension_contains_no_trash_operation(self):
        combined = "\n".join(
            (ROOT / name).read_text(encoding="utf-8")
            for name in ("content.js", "page-bridge.js", "popup.js", "popup.html", "manifest.json")
        )
        self.assertNotIn('type: "TRASH"', combined)
        self.assertNotIn('data.type === "TRASH"', combined)
        self.assertNotIn('"XwAOJf"', combined)
        self.assertNotIn("已刪除", combined)
        self.assertNotIn("移到垃圾桶", combined)

    def test_manifest_loads_selection_helper_before_content_script(self):
        manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
        isolated = next(
            item for item in manifest["content_scripts"] if item.get("world") == "ISOLATED"
        )
        self.assertEqual(isolated["js"], ["selection.js", "content.js"])
        self.assertTrue((ROOT / "selection.js").is_file())

    def test_ui_describes_selection_behavior(self):
        popup = (ROOT / "popup.html").read_text(encoding="utf-8")
        script = (ROOT / "popup.js").read_text(encoding="utf-8")
        manifest = (ROOT / "manifest.json").read_text(encoding="utf-8")
        self.assertIn("選取占用空間的照片", popup)
        self.assertIn("已選取", script)
        self.assertIn("選取", manifest)


if __name__ == "__main__":
    unittest.main()
