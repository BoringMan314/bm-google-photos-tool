const assert = require("assert");
const { selectTileRoot } = require("../selection.js");

function control(attrs = {}) {
  return {
    disabled: false,
    clicks: 0,
    checked: false,
    getAttribute(name) {
      return attrs[name] ?? null;
    },
    click() {
      this.clicks += 1;
    },
  };
}

async function main() {
  const unrelated = control({ "aria-label": "其他選項", "aria-checked": "false" });
  const selectPhoto = control({ "aria-label": "選取相片", "aria-checked": "false" });
  const root = {
    querySelector(selector) {
      if (selector === '[role="checkbox"]') return unrelated;
      if (selector.includes('aria-label*="選取"')) return selectPhoto;
      return null;
    },
  };
  const result = await selectTileRoot(root);
  assert.equal(result.ok, true);
  assert.equal(selectPhoto.clicks, 1, "應點擊明確標示的選取相片控制項");
  assert.equal(unrelated.clicks, 0, "不得誤點其他核取方塊");

  const selected = control({ "aria-label": "選取相片", "aria-checked": "true" });
  const selectedRoot = {
    querySelector(selector) {
      return selector.includes('aria-label*="選取"') ? selected : null;
    },
  };
  const existing = await selectTileRoot(selectedRoot);
  assert.equal(existing.ok, true);
  assert.equal(existing.changed, false);
  assert.equal(selected.clicks, 0, "已選取的相片不得再次點擊而取消選取");
  console.log("selection behavior tests passed");
}

main().catch((error) => {
  console.error(error.stack || error);
  process.exit(1);
});
