(function exposeGpsfSelection(globalObject) {
  const CONTROL_SELECTORS = [
    'button[aria-label*="選取"]',
    '[aria-label*="選取相片"]',
    '[aria-label*="選取照片"]',
    'button[aria-label*="Select"]',
    '[aria-label*="Select photo"]',
    '[role="checkbox"]',
  ];

  function isSelected(control) {
    if (!control) return false;
    return (
      control.getAttribute?.("aria-checked") === "true" ||
      control.getAttribute?.("aria-pressed") === "true" ||
      control.checked === true
    );
  }

  function findSelectionControl(root) {
    if (!root?.querySelector) return null;
    for (const selector of CONTROL_SELECTORS) {
      const control = root.querySelector(selector);
      if (control && !control.disabled) return control;
    }
    return null;
  }

  function revealSelectionControl(root) {
    if (!root?.dispatchEvent || typeof MouseEvent === "undefined") return;
    for (const type of ["mouseenter", "mouseover", "mousemove"]) {
      root.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: globalObject }));
    }
  }

  async function selectTileRoot(root) {
    if (!root) return { ok: false, reason: "找不到相片圖塊" };
    revealSelectionControl(root);
    let control = findSelectionControl(root);
    if (!control && typeof globalObject.requestAnimationFrame === "function") {
      await new Promise((resolve) => globalObject.requestAnimationFrame(resolve));
      control = findSelectionControl(root);
    }
    if (!control) return { ok: false, reason: "找不到選取按鈕" };
    if (isSelected(control)) return { ok: true, changed: false };
    control.click();
    return { ok: true, changed: true };
  }

  const api = { findSelectionControl, isSelected, selectTileRoot };
  globalObject.GPSFSelection = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : window);
