const PHOTOS_ORIGIN = "https://photos.google.com";

const runButton = document.getElementById("run");
const hint = document.getElementById("hint");
const stats = document.getElementById("stats");

function isPhotosUrl(url) {
  return typeof url === "string" && url.startsWith(PHOTOS_ORIGIN);
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function sendToTab(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch {
    return null;
  }
}

function renderRunButton(running) {
  runButton.classList.toggle("running", running);
  runButton.textContent = running ? "停止" : "執行";
}

async function refreshStatus() {
  const tab = await getActiveTab();
  if (!tab || !isPhotosUrl(tab.url)) {
    hint.hidden = false;
    hint.classList.add("warn");
    hint.textContent = "請先開啟 photos.google.com 再使用。";
    stats.hidden = true;
    renderRunButton(false);
    runButton.disabled = true;
    return;
  }

  runButton.disabled = false;
  hint.hidden = false;
  hint.classList.remove("warn");
  hint.textContent =
    "占用空間的照片會被選取，不會刪除。未占用的會隱藏，並繼續往下掃描。";

  const response = await sendToTab(tab.id, { type: "GPSF_GET_STATUS" });
  const running = Boolean(response?.running);
  renderRunButton(running);

  if (!response) {
    stats.hidden = true;
    return;
  }

  stats.hidden = false;
  const scanned = response.scanned ?? 0;
  const selected = response.selected || 0;
  if (running) {
    stats.textContent = `執行中：已掃描 ${scanned} 張，已選取 ${selected} 張。`;
  } else if (response.scanDone) {
    stats.textContent = `已完成：已掃描 ${scanned} 張，已選取 ${selected} 張。`;
  } else {
    stats.textContent = "尚未執行。";
  }
}

runButton.addEventListener("click", async () => {
  const tab = await getActiveTab();
  if (!tab || !isPhotosUrl(tab.url)) return;

  const status = await sendToTab(tab.id, { type: "GPSF_GET_STATUS" });
  const running = Boolean(status?.running);
  await sendToTab(tab.id, { type: running ? "GPSF_STOP" : "GPSF_START" });
  await refreshStatus();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.runStats) {
    refreshStatus();
  }
});

window.setInterval(refreshStatus, 400);
refreshStatus();
