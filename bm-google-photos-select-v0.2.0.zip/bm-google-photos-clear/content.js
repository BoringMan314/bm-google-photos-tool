const CHANNEL = "gpsf";
const HIDDEN_CLASS = "gpsf-hidden";
const BATCH_SIZE = 40;
const SCAN_DELAY_MS = 200;

const state = {
  enabled: false,
  cache: new Map(),
  inflight: new Set(),
  queued: new Set(),
  queue: [],
  lookingUp: false,
  lastError: "",
  observer: null,
  scanTimer: 0,
  scanToken: 0,
  scrolling: false,
  scanDone: false,
  listing: false,
  listedCount: 0,
  selectedKeys: new Set(),
  selecting: new Set(),
};

let requestId = 0;
const pending = new Map();

function wait(ms) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function postToPage(message, timeoutMs = 45000) {
  return new Promise((resolve, reject) => {
    const id = `gpsf-${++requestId}`;
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error("與頁面通訊逾時，請重新整理後再試"));
    }, timeoutMs);

    pending.set(id, {
      resolve: (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      reject: (error) => {
        clearTimeout(timer);
        reject(error);
      },
    });

    window.postMessage({ channel: CHANNEL, from: "content", id, ...message }, "*");
  });
}

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const data = event.data;
  if (!data || data.channel !== CHANNEL || data.from !== "bridge") return;
  const waiter = pending.get(data.id);
  if (!waiter) return;
  pending.delete(data.id);
  if (data.error) waiter.reject(new Error(data.error));
  else waiter.resolve(data.payload);
});

function detectContext() {
  const path = (location.pathname || "/").replace(/^\/u\/\d+/, "") || "/";
  const params = new URLSearchParams(location.search);

  const album = path.match(/^\/album\/([^/]+)/);
  if (album) {
    return {
      source: "album",
      albumKey: decodeURIComponent(album[1]),
      authKey: params.get("key"),
    };
  }

  const share = path.match(/^\/share\/([^/]+)/);
  if (share) {
    return {
      source: "album",
      albumKey: decodeURIComponent(share[1]),
      authKey: params.get("key"),
    };
  }

  const search = path.match(/^\/search\/(.+)$/);
  if (search) {
    return { source: "search", query: decodeURIComponent(search[1]) };
  }

  if (/trash|bin/i.test(path)) return { source: "trash" };
  if (/locked/i.test(path)) return { source: "locked" };
  if (/archive/i.test(path)) return { source: "archive" };
  if (/favorite/i.test(path)) return { source: "favorites" };
  return { source: "library" };
}

function extractMediaKey(href) {
  if (!href) return "";
  const match = href.match(/\/photo\/([^/?#]+)/);
  return match ? decodeURIComponent(match[1]) : "";
}

function isGridTile(anchor) {
  if (anchor.closest("[role='dialog'], [aria-modal='true']")) return false;
  const rect = anchor.getBoundingClientRect();
  if (rect.width < 48 || rect.height < 48) return false;
  if (rect.width > 720 || rect.height > 720) return false;
  return true;
}

function collectTiles() {
  const tiles = [];
  const seen = new Set();
  document.querySelectorAll('a[href*="/photo/"]').forEach((anchor) => {
    const mediaKey = extractMediaKey(anchor.getAttribute("href"));
    if (!mediaKey || seen.has(mediaKey) || !isGridTile(anchor)) return;
    seen.add(mediaKey);
    tiles.push({ el: anchor, mediaKey });
  });
  return tiles;
}

function tileRoot(anchor) {
  const aRect = anchor.getBoundingClientRect();
  let node = anchor.parentElement;
  let best = anchor;
  for (let i = 0; i < 4 && node && node !== document.body; i += 1) {
    const rect = node.getBoundingClientRect();
    const similarSize =
      Math.abs(rect.width - aRect.width) < 48 &&
      Math.abs(rect.height - aRect.height) < 48;
    if (similarSize) best = node;
    node = node.parentElement;
  }
  return best;
}

function hideElement(el, hide) {
  if (hide) el.classList.add(HIDDEN_CLASS);
  else el.classList.remove(HIDDEN_CLASS);
}

function applyTileVisibility(tile) {
  const info = state.cache.get(tile.mediaKey);
  const shouldHide = info?.takesUpSpace === false;
  hideElement(tile.el, shouldHide);
  hideElement(tileRoot(tile.el), shouldHide);
  if (state.enabled && info?.takesUpSpace === true) {
    void scheduleTileSelection(tile);
  }
}

function isLookedUp(info) {
  return Boolean(info) && Object.prototype.hasOwnProperty.call(info, "takesUpSpace");
}

function getScannedCount() {
  let lookedUp = 0;
  state.cache.forEach((info) => {
    if (isLookedUp(info)) lookedUp += 1;
  });
  return Math.max(state.listedCount, lookedUp);
}

function getStats() {
  return {
    running: state.enabled,
    scanned: getScannedCount(),
    selected: state.selectedKeys.size,
    scanDone: state.scanDone,
  };
}

let statsWriteTimer = 0;
function persistStats() {
  window.clearTimeout(statsWriteTimer);
  statsWriteTimer = window.setTimeout(() => {
    try {
      chrome.storage.local.set({ runStats: getStats() });
    } catch {}
  }, 120);
}

function updateHud() {
  let hud = document.getElementById("gpsf-hud");
  if (!state.enabled && !state.scanDone) {
    if (hud) hud.remove();
    persistStats();
    return;
  }

  if (!hud) {
    hud = document.createElement("div");
    hud.id = "gpsf-hud";
    document.documentElement.appendChild(hud);
  }

  const scanned = getScannedCount();
  const extra = state.lastError ? `｜${state.lastError}` : "";
  if (state.enabled) {
    hud.textContent = `執行中｜已掃描 ${scanned}｜已選取 ${state.selectedKeys.size}${extra}`;
  } else {
    hud.textContent = `執行完成｜已掃描 ${scanned}｜已選取 ${state.selectedKeys.size}${extra}`;
  }
  persistStats();
}

function maybeFinish(token) {
  if (state.scanToken !== token || !state.enabled) return;
  if (
    state.listing ||
    state.lookingUp ||
    state.scrolling ||
    state.queue.length ||
    state.selecting.size
  ) return;
  state.scanDone = true;
  state.enabled = false;
  chrome.storage.local.set({ running: false });
  collectTiles().forEach(applyTileVisibility);
  updateHud();
}

function rememberItem(item) {
  if (!item?.mediaKey) return;
  const prev = state.cache.get(item.mediaKey) || {};
  state.cache.set(item.mediaKey, {
    ...prev,
    dedupKey: item.dedupKey || prev.dedupKey || "",
  });
}

async function scheduleTileSelection(tile) {
  if (
    !state.enabled ||
    state.selectedKeys.has(tile.mediaKey) ||
    state.selecting.has(tile.mediaKey)
  ) return;
  state.selecting.add(tile.mediaKey);
  try {
    const result = await globalThis.GPSFSelection.selectTileRoot(tileRoot(tile.el));
    if (result.ok) {
      state.selectedKeys.add(tile.mediaKey);
      state.lastError = "";
    } else {
      state.lastError = result.reason || "無法選取相片";
    }
  } catch (error) {
    state.lastError = error instanceof Error ? error.message : String(error);
  } finally {
    state.selecting.delete(tile.mediaKey);
    updateHud();
    maybeFinish(state.scanToken);
  }
}

async function selectConsuming(mediaKeys) {
  const wanted = new Set(
    mediaKeys.filter((mediaKey) => state.cache.get(mediaKey)?.takesUpSpace === true)
  );
  for (const tile of collectTiles()) {
    if (!state.enabled) return;
    if (wanted.has(tile.mediaKey)) await scheduleTileSelection(tile);
  }
}

async function lookupKeys(mediaKeys) {
  const payload = await postToPage({ type: "LOOKUP", mediaKeys });
  const seen = new Set();
  (payload || []).forEach((item) => {
    if (!item?.mediaKey) return;
    seen.add(item.mediaKey);
    state.cache.set(item.mediaKey, {
      ...state.cache.get(item.mediaKey),
      takesUpSpace: item.takesUpSpace,
      dedupKey: item.dedupKey || state.cache.get(item.mediaKey)?.dedupKey || "",
    });
  });
  return mediaKeys.filter((key) => !seen.has(key));
}

async function drainQueue() {
  if (state.lookingUp) return;
  state.lookingUp = true;
  try {
    while (state.enabled && state.queue.length) {
      const batch = state.queue.splice(0, BATCH_SIZE);
      batch.forEach((key) => {
        state.queued.delete(key);
        state.inflight.add(key);
      });
      try {
        const missing = await lookupKeys(batch);
        missing.forEach((key) => {
          state.cache.set(key, {
            ...state.cache.get(key),
            takesUpSpace: null,
          });
        });
        await selectConsuming(batch);
        state.lastError = "";
      } catch (error) {
        state.lastError = error instanceof Error ? error.message : String(error);
        batch.forEach((key) => {
          state.cache.set(key, {
            ...state.cache.get(key),
            takesUpSpace: state.cache.get(key)?.takesUpSpace ?? null,
          });
        });
      } finally {
        batch.forEach((key) => state.inflight.delete(key));
      }
      collectTiles().forEach(applyTileVisibility);
      updateHud();
    }
  } finally {
    state.lookingUp = false;
    maybeFinish(state.scanToken);
  }
}

function enqueueUnknown(mediaKeys) {
  mediaKeys.forEach((key) => {
    if (!key || state.inflight.has(key) || state.queued.has(key)) return;
    if (isLookedUp(state.cache.get(key))) return;
    state.queued.add(key);
    state.queue.push(key);
  });
  drainQueue();
}

function scan() {
  const tiles = collectTiles();
  tiles.forEach(applyTileVisibility);
  if (state.enabled) enqueueUnknown(tiles.map((tile) => tile.mediaKey));
  updateHud();
}

function scheduleScan() {
  window.clearTimeout(state.scanTimer);
  state.scanTimer = window.setTimeout(scan, SCAN_DELAY_MS);
}

function findScrollContainer() {
  const fallback = document.scrollingElement || document.documentElement;
  let best = fallback;
  let bestOverflow = Math.max(0, fallback.scrollHeight - fallback.clientHeight);
  document.querySelectorAll('[role="main"], c-wiz').forEach((el) => {
    if (el.clientHeight < 240) return;
    const overflowY = getComputedStyle(el).overflowY;
    if (overflowY !== "auto" && overflowY !== "scroll") return;
    const extra = el.scrollHeight - el.clientHeight;
    if (extra > bestOverflow) {
      best = el;
      bestOverflow = extra;
    }
  });
  return best;
}

function setScrollTop(scroller, top) {
  if (
    scroller === document.scrollingElement ||
    scroller === document.documentElement ||
    scroller === document.body
  ) {
    window.scrollTo(0, top);
    return;
  }
  scroller.scrollTop = top;
}

async function autoScrollAll(token) {
  state.scrolling = true;
  await wait(400);
  const scroller = findScrollContainer();
  setScrollTop(scroller, 0);
  scan();

  let stuck = 0;
  let lastHeight = 0;
  let lastTop = -1;
  const started = Date.now();

  while (state.enabled && state.scanToken === token && Date.now() - started < 20 * 60 * 1000) {
    scan();
    const prevHeight = scroller.scrollHeight;
    const maxTop = Math.max(0, prevHeight - scroller.clientHeight);
    const step = Math.max(Math.floor(scroller.clientHeight * 0.8), 500);
    setScrollTop(scroller, Math.min(maxTop, (scroller.scrollTop || 0) + step));

    const waitStart = Date.now();
    while (Date.now() - waitStart < 900 && state.enabled && state.scanToken === token) {
      if (scroller.scrollHeight > prevHeight + 24) break;
      await wait(100);
      updateHud();
    }

    scan();
    const top = scroller.scrollTop;
    const atBottom = top >= maxTop - 12;
    const noGrowth = scroller.scrollHeight <= lastHeight + 8;
    if ((atBottom && noGrowth) || (top === lastTop && noGrowth)) stuck += 1;
    else stuck = 0;
    lastHeight = scroller.scrollHeight;
    lastTop = top;
    if (stuck >= 8) break;
  }

  if (state.enabled && state.scanToken === token) {
    setScrollTop(scroller, 0);
    scan();
  }
  if (state.scanToken === token) {
    state.scrolling = false;
    maybeFinish(token);
  }
}

async function fullScan(token) {
  const ctx = detectContext();
  state.scanDone = false;
  state.listing = true;
  state.listedCount = 0;
  state.lastError = "";
  updateHud();

  const allKeys = [];
  const seenKeys = new Set();
  const seenPages = new Set();
  let pageId = null;
  let timestamp = null;
  let emptyStreak = 0;

  try {
    do {
      if (!state.enabled || state.scanToken !== token) return;
      const page = await postToPage({
        type: "LIST_PAGE",
        source: ctx.source,
        pageId,
        timestamp,
        albumKey: ctx.albumKey,
        authKey: ctx.authKey,
        query: ctx.query,
      });
      const items = page?.items || [];
      const keys = items.map((item) => item.mediaKey).filter(Boolean);
      items.forEach(rememberItem);
      keys.forEach((key) => {
        if (seenKeys.has(key)) return;
        seenKeys.add(key);
        allKeys.push(key);
      });
      state.listedCount = allKeys.length;
      enqueueUnknown(keys);
      collectTiles().forEach(applyTileVisibility);
      updateHud();

      if (!keys.length) emptyStreak += 1;
      else emptyStreak = 0;
      if (emptyStreak >= 3) break;

      const next = page?.nextPageId || null;
      if (next && seenPages.has(next)) break;
      if (next) seenPages.add(next);
      pageId = next;
      if (page?.lastItemTimestamp && !Number.isNaN(page.lastItemTimestamp)) {
        timestamp = page.lastItemTimestamp - 1;
      }
    } while (pageId);

    if (!state.enabled || state.scanToken !== token) return;
    state.listing = false;
    enqueueUnknown(allKeys);
    collectTiles().forEach(applyTileVisibility);
    updateHud();
  } catch (error) {
    if (state.scanToken !== token) return;
    state.lastError = error instanceof Error ? error.message : String(error);
    updateHud();
  } finally {
    if (state.scanToken === token) {
      state.listing = false;
      maybeFinish(token);
    }
  }
}

function startJobs(token) {
  updateHud();
  scan();
  fullScan(token);
  autoScrollAll(token);
}

function setEnabled(enabled) {
  enabled = Boolean(enabled);
  if (state.enabled === enabled) return;

  state.enabled = enabled;
  state.scanToken += 1;
  if (!state.enabled) {
    state.queue = [];
    state.queued.clear();
    state.scrolling = false;
    state.scanDone = false;
    state.listing = false;
    chrome.storage.local.set({ running: false });
    updateHud();
    return;
  }

  state.scanDone = false;
  state.selectedKeys.clear();
  state.selecting.clear();
  state.cache.clear();
  chrome.storage.local.set({ running: true });
  startJobs(state.scanToken);
}

function startUrlWatch() {
  let lastPath = location.pathname + location.search;
  window.setInterval(() => {
    if (!state.enabled) return;
    const now = location.pathname + location.search;
    if (now === lastPath) return;
    lastPath = now;
    state.scanToken += 1;
    state.scanDone = false;
    startJobs(state.scanToken);
  }, 800);
}

function startObserver() {
  if (state.observer) return;
  state.observer = new MutationObserver(() => {
    if (state.enabled) scheduleScan();
  });
  state.observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
  });
  window.addEventListener("scroll", scheduleScan, { passive: true });
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "GPSF_START") {
    setEnabled(true);
    sendResponse(getStats());
    return true;
  }
  if (message?.type === "GPSF_STOP") {
    setEnabled(false);
    sendResponse(getStats());
    return true;
  }
  if (message?.type === "GPSF_GET_STATUS") {
    sendResponse(getStats());
    return true;
  }
  return false;
});

async function init() {
  try {
    startObserver();
    startUrlWatch();
  } catch (error) {
    console.warn("[GPSF] init", error);
  }
}

init();
